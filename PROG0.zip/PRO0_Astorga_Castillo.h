/*
 * Instituto Tecnologico de Costa Rica
 * Escuela de Ingenieria en Computacion
 * Computer Graphics
 *
 * Programa: CG-PROG0
 * Archivo: CG-PROG0_GeovannyAstorga_MaurcioCastillo.c
 */

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
 


typedef struct
{
	int x;
	int y;
} Matriz;